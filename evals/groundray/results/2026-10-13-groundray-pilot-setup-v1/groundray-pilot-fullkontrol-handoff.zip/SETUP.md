# Fullkontrol pilot packet

Verify and extract the original packet from this directory:

```sh
python3 - <<'PY'
import hashlib, json
from pathlib import Path
expected = json.loads(Path('archive.json').read_text())['sha256']
assert hashlib.sha256(Path('groundray-pilot.zip').read_bytes()).hexdigest() == expected
print('Packet SHA-256 verified')
PY
unzip -q groundray-pilot.zip -d pilot-packet
python3 current-tools/provision_groundray_pilot.py \
  --repository fullkontrol/groundray-pilot-mosaic --publisher MarvinAmador7 \
  --employee KarolGarcia712 --packet "$PWD/pilot-packet"
python3 current-tools/provision_groundray_pilot.py \
  --repository fullkontrol/groundray-pilot-mosaic --publisher MarvinAmador7 \
  --employee KarolGarcia712 --packet "$PWD/pilot-packet" \
  --apply --log "$PWD/fullkontrol-provisioning/provisioning.jsonl"
```

Use your existing MarvinAmador7 GitHub login with organization creation/admin
rights. Read ORGANIZATION.md for the exact policy, host-plan gate, role/version
recording and pending real participant tests. The original packet's embedded
provisioner predates organization support; use current-tools instead.
